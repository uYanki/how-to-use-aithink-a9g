#ifndef _GPRS_H_
#define _GPRS_H_

#include "sys.h"

#define	NO_ERROR	0
#define NO_RESPOND	1	//û����Ӧ
#define AT_ERROR  2
#define AT_CGATT_ERROR  3
#define AT_CGDCONT_ERROR  4
#define AT_CGACT_ERROR	5
#define AT_GPS_ERROR  6
#define AT_GPSMD_ERROR	7
#define AT_GPSRD_ERROR  8
#define	AT_AGPS_ERROR		9		
#define AT_CIPSTART_ERROR 10
#define AT_CIPSEND_ERROR 11
#define AT_CIPTMODE_ERROR 12
#define SEND_NUM_ERROR  13
#define AT_CSQ_ERROR  14
#define CSQ_CHECK_ERROR 15
#define AT_EGMR_ERROR 16
#define AT_CCID_ERROR 17
#define AT_CIPCLOSE_ERROR 18




#define MEN_ERROR  100
#define CONNECT_INTE_ERROR 101

u8 send_com(u8 *send,u8 *respond);
u8 connect_internet(void);
u8 open_gps(u8 *data);
u8 open_agps(u8 *agps);
u8 socket_TCP(char *IP,char *port);
u8 send_data(char *data);
void Getdata_Server(u8 *data);
u8 get_gprs_message(u8* data);
void A9G_init(void);
#endif

