#ifndef _IWDG_H_
#define _IWDG_H_

#include "sys.h"
//#include "stm32f10x_iwdg.h"

void IWDG_init(u8 prer,u16 ulr);
void IWDG_Feed(void);



#endif
